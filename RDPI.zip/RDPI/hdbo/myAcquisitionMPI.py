from collections import defaultdict
import math
from GPyOpt.acquisitions import AcquisitionMPI
import numpy as np
#import mlflow_logging
from scipy.special import erfc

def get_quantiles(acquisition_par, fmin, m, s):
    '''
    Quantiles of the Gaussian distribution useful to determine the acquisition function values
    :param acquisition_par: parameter of the acquisition function
    :param fmin: current minimum.
    :param m: vector of means.
    :param s: vector of standard deviations.
    '''
    if isinstance(s, np.ndarray):
        s[s<1e-10] = 1e-10
    elif s< 1e-10:
        s = 1e-10
    u = (fmin - m - acquisition_par)/s
    phi = np.exp(-0.5 * u**2) / np.sqrt(2*np.pi)
    Phi = 0.5 * erfc(-u / np.sqrt(2))
    return (phi, Phi, u)

class MyAcquisitionMPI(AcquisitionMPI):
    def __init__(self, model, kernel, variables):
        super(AcquisitionMPI, self).__init__(model=model, space=None, optimizer=None, cost_withGradients=None)
        self.dimension = kernel.input_dim
        self.kernel = kernel
        self.variables = variables
        self.jitter = 0.01

    # Special computation to compute the exact kernel ad it relies on the model
    def _compute_acq(self, x):
        m, s = self.model.predict_with_kernel(x, self.kernel) 
        fmin = self.model.get_fmin()
        _, Phi, _ = get_quantiles(self.jitter, fmin, m, s)
        f_acqu = Phi
        return f_acqu

    def _compute_acq_withGradients(self, x):
        fmin = self.model.get_fmin()
        m, s, dmdx, dsdx = self.model.predict_withGradients_with_kernel(x, self.kernel)
        phi, Phi, u = get_quantiles(self.jitter, fmin, m, s)
        f_acqu = Phi
        df_acqu = -(phi/s)*(dmdx + dsdx * u)
        return f_acqu, df_acqu

    # We override the default because of potential issues 
    def acquisition_function(self, x):
        f_acqu = self._compute_acq(x)
        return -f_acqu

    def acquisition_function_withGradients(self, x):
        f_acqu,df_acqu = self._compute_acq_withGradients(x)
        return -f_acqu, -df_acqu

    def __call__(self, x):
        return self.acquisition_function(x)