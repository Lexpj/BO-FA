import numpy as np

def ball(x):
    return 2*(np.linalg.norm(x)**2 - 1)

