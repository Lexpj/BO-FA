"""

Controller
----------

.. autosummary::
   :template: template.rst
   :toctree:

   Controller
   SimpleController
   RepetitionController
   SequentialController
   PlottingController

"""


from hdbo.febo.controller.controller import Controller, ControllerConfig
from hdbo.febo.controller.simple import SimpleController
from hdbo.febo.controller.multi import RepetitionController, SequentialController
from hdbo.febo.controller.plotting import PlottingController

